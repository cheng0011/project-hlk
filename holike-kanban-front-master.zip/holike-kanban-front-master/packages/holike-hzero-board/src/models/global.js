import { getGlobalModalConfig } from 'hzero-front/lib/models/global';
import { getWrapperRouterData } from '@/utils/router';

export default getGlobalModalConfig({ getWrapperRouterData, app: window.dvaApp });
