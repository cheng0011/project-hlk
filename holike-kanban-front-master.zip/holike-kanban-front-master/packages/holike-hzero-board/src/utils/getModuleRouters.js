import { getModuleRouters } from 'utils/utils';

export default app => getModuleRouters(app, []);