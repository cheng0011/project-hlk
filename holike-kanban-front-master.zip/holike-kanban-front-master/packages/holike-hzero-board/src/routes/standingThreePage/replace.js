import React from "react";

class Replace extends React.Component {
  componentWillMount() {
    window.open("/pub/holike-hzero-board/standingThreePage/index");
  }

  render() {
    return "";
  }
}

export default Replace;