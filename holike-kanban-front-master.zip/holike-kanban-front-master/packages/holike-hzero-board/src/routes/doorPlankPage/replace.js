import React from "react";

class Replace extends React.Component {
  componentWillMount() {
    window.open("/pub/holike-hzero-board/doorPlankPage/index");
  }

  render() {
    return "";
  }
}

export default Replace;
