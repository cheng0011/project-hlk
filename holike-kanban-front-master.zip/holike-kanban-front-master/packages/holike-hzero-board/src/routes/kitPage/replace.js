import React from "react";

class Replace extends React.Component {
  componentWillMount() {
    window.open("/pub/holike-hzero-board/kitPage/index");
  }

  render() {
    return "";
  }
}

export default Replace;