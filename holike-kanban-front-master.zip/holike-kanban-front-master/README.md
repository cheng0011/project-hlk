`holike-kanban-front`
===
> TODO: description
## 使用
```
安装依赖: lerna bootstrap --registry=http://nexus.saas.hand-china.com/content/groups/hzero-npm-group;
编译 子服务: lerna run transpile; (执行所有子服务的transpile命令)
编译 dll: yarn build:dll; (开发环境 可以 执行 yarn build:dll-dev)
启动: yarn start;
// TODO: DEMONSTRATE API
```